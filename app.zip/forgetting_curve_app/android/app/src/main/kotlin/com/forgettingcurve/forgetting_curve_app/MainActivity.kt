package com.forgettingcurve.forgetting_curve_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
