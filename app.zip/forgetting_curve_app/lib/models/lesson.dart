class Lesson {
  int? id;
  String name;
  String subject;
  String note;
  DateTime createdAt;
  DateTime? lastReviewed;
  int reviewCount;
  DateTime? nextReviewDate;
  int xpPoints;

  Lesson({
    this.id,
    required this.name,
    required this.subject,
    required this.note,
    required this.createdAt,
    this.lastReviewed,
    this.reviewCount = 0,
    this.nextReviewDate,
    this.xpPoints = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'subject': subject,
      'note': note,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'lastReviewed': lastReviewed?.millisecondsSinceEpoch,
      'reviewCount': reviewCount,
      'nextReviewDate': nextReviewDate?.millisecondsSinceEpoch,
      'xpPoints': xpPoints,
    };
  }

  factory Lesson.fromMap(Map<String, dynamic> map) {
    return Lesson(
      id: map['id'],
      name: map['name'],
      subject: map['subject'],
      note: map['note'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      lastReviewed: map['lastReviewed'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['lastReviewed'])
          : null,
      reviewCount: map['reviewCount'],
      nextReviewDate: map['nextReviewDate'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['nextReviewDate'])
          : null,
      xpPoints: map['xpPoints'],
    );
  }
}
