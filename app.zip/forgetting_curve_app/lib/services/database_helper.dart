import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/lesson.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('forgetting_curve.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE lessons(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        subject TEXT NOT NULL,
        note TEXT,
        createdAt INTEGER NOT NULL,
        lastReviewed INTEGER,
        reviewCount INTEGER NOT NULL,
        nextReviewDate INTEGER,
        xpPoints INTEGER NOT NULL
      )
    ''');
  }

  Future<int> insertLesson(Lesson lesson) async {
    final db = await database;
    return await db.insert('lessons', lesson.toMap());
  }

  Future<List<Lesson>> getLessons() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('lessons');
    return List.generate(maps.length, (i) => Lesson.fromMap(maps[i]));
  }

  Future<List<Lesson>> getLessonsToReview() async {
    final db = await database;
    final now = DateTime.now().millisecondsSinceEpoch;
    final List<Map<String, dynamic>> maps = await db.query(
      'lessons',
      where: 'nextReviewDate <= ? OR nextReviewDate IS NULL',
      whereArgs: [now],
    );
    return List.generate(maps.length, (i) => Lesson.fromMap(maps[i]));
  }

  Future<int> updateLesson(Lesson lesson) async {
    final db = await database;
    return await db.update(
      'lessons',
      lesson.toMap(),
      where: 'id = ?',
      whereArgs: [lesson.id],
    );
  }

  Future<int> deleteLesson(int id) async {
    final db = await database;
    return await db.delete(
      'lessons',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Lesson>> searchLessons(String query) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'lessons',
      where: 'name LIKE ? OR subject LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
    );
    return List.generate(maps.length, (i) => Lesson.fromMap(maps[i]));
  }

  Future<List<Lesson>> filterLessonsBySubject(String subject) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'lessons',
      where: 'subject = ?',
      whereArgs: [subject],
    );
    return List.generate(maps.length, (i) => Lesson.fromMap(maps[i]));
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
