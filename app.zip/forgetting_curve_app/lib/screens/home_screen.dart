import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/lesson.dart';
import '../services/database_helper.dart';
import '../services/forgetting_curve_service.dart';
import 'add_lesson_screen.dart';
import 'review_lesson_screen.dart';
import 'memory_graph_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  List<Lesson> _lessons = [];
  List<Lesson> _lessonsToReview = [];
  int _totalXp = 0;
  String _searchQuery = '';
  String _selectedSubject = '';
  List<String> _subjects = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
    });

    // تحميل الدروس من قاعدة البيانات
    final lessons = await _databaseHelper.getLessons();
    final lessonsToReview = await _databaseHelper.getLessonsToReview();
    
    // حساب مجموع نقاط XP
    int totalXp = 0;
    for (var lesson in lessons) {
      totalXp += lesson.xpPoints;
    }
    
    // استخراج المواد الفريدة للتصفية
    final subjects = <String>{};
    for (var lesson in lessons) {
      if (lesson.subject.isNotEmpty) {
        subjects.add(lesson.subject);
      }
    }

    setState(() {
      _lessons = lessons;
      _lessonsToReview = lessonsToReview;
      _totalXp = totalXp;
      _subjects = subjects.toList()..sort();
      _isLoading = false;
    });
  }

  Future<void> _reviewLesson(Lesson lesson) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ReviewLessonScreen(lesson: lesson),
      ),
    );

    if (result == true) {
      await _loadData();
    }
  }

  Future<void> _addNewLesson() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddLessonScreen(),
      ),
    );

    if (result == true) {
      await _loadData();
    }
  }

  Future<void> _deleteLesson(Lesson lesson) async {
    await _databaseHelper.deleteLesson(lesson.id!);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تم حذف "${lesson.name}" بنجاح')),
    );
    await _loadData();
  }

  Future<void> _searchLessons(String query) async {
    setState(() {
      _searchQuery = query;
      _selectedSubject = '';
    });
    await _loadData();
  }

  Future<void> _filterBySubject(String subject) async {
    setState(() {
      _selectedSubject = subject;
      _searchQuery = '';
    });
    await _loadData();
  }

  List<Lesson> _getFilteredLessons() {
    if (_searchQuery.isNotEmpty) {
      return _lessons
          .where((lesson) =>
              lesson.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              lesson.subject.toLowerCase().contains(_searchQuery.toLowerCase()))
          .toList();
    } else if (_selectedSubject.isNotEmpty) {
      return _lessons
          .where((lesson) => lesson.subject == _selectedSubject)
          .toList();
    }
    return _lessons;
  }

  @override
  Widget build(BuildContext context) {
    final filteredLessons = _getFilteredLessons();

    return Scaffold(
      appBar: AppBar(
        title: Text('مراجعة منحنى النسيان'),
        actions: [
          IconButton(
            icon: Icon(Icons.bar_chart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MemoryGraphScreen(lessons: _lessons),
                ),
              );
            },
            tooltip: 'رسم بياني للذاكرة',
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // قسم البحث والتصفية
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'بحث عن درس',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onChanged: _searchLessons,
                      ),
                      SizedBox(height: 8),
                      if (_subjects.isNotEmpty)
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 8.0),
                                child: FilterChip(
                                  label: Text('الكل'),
                                  selected: _selectedSubject.isEmpty,
                                  onSelected: (selected) {
                                    if (selected) {
                                      setState(() {
                                        _selectedSubject = '';
                                      });
                                      _loadData();
                                    }
                                  },
                                ),
                              ),
                              ..._subjects.map((subject) => Padding(
                                    padding: const EdgeInsets.only(right: 8.0),
                                    child: FilterChip(
                                      label: Text(subject),
                                      selected: _selectedSubject == subject,
                                      onSelected: (selected) {
                                        if (selected) {
                                          _filterBySubject(subject);
                                        }
                                      },
                                    ),
                                  )),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),

                // قسم XP والدروس للمراجعة
                Container(
                  padding: EdgeInsets.all(16),
                  color: Colors.blue.shade50,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'نقاط XP: $_totalXp',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'دروس للمراجعة: ${_lessonsToReview.length}',
                            style: TextStyle(
                              fontSize: 16,
                              color: _lessonsToReview.isNotEmpty
                                  ? Colors.red
                                  : Colors.green,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      if (_lessonsToReview.isNotEmpty)
                        ElevatedButton(
                          onPressed: () => _reviewLesson(_lessonsToReview.first),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                          ),
                          child: Text('مراجعة الآن'),
                        ),
                    ],
                  ),
                ),

                // قائمة الدروس
                Expanded(
                  child: filteredLessons.isEmpty
                      ? Center(
                          child: Text(
                            'لا توجد دروس. أضف دروساً جديدة للبدء!',
                            style: TextStyle(fontSize: 16),
                          ),
                        )
                      : ListView.builder(
                          itemCount: filteredLessons.length,
                          itemBuilder: (context, index) {
                            final lesson = filteredLessons[index];
                            final needsReview = _lessonsToReview
                                .any((l) => l.id == lesson.id);
                            
                            return Card(
                              margin: EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              color: needsReview
                                  ? Colors.amber.shade50
                                  : Colors.white,
                              child: ListTile(
                                title: Text(
                                  lesson.name,
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('المادة: ${lesson.subject}'),
                                    Text(
                                      'المراجعات: ${lesson.reviewCount} | XP: ${lesson.xpPoints}',
                                    ),
                                    if (lesson.nextReviewDate != null)
                                      Text(
                                        'المراجعة التالية: ${_formatDate(lesson.nextReviewDate!)}',
                                        style: TextStyle(
                                          color: needsReview
                                              ? Colors.red
                                              : Colors.green,
                                        ),
                                      ),
                                  ],
                                ),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      icon: Icon(Icons.refresh,
                                          color: Colors.blue),
                                      onPressed: () => _reviewLesson(lesson),
                                      tooltip: 'مراجعة',
                                    ),
                                    IconButton(
                                      icon: Icon(Icons.delete,
                                          color: Colors.red),
                                      onPressed: () => _deleteLesson(lesson),
                                      tooltip: 'حذف',
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewLesson,
        child: Icon(Icons.add),
        tooltip: 'إضافة درس جديد',
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now).inDays;

    if (difference == 0) {
      return 'اليوم';
    } else if (difference == 1) {
      return 'غداً';
    } else if (difference > 1 && difference < 7) {
      return 'بعد $difference أيام';
    } else {
      return '${date.year}/${date.month}/${date.day}';
    }
  }
}
