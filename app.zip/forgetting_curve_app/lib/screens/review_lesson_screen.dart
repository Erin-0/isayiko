import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../services/database_helper.dart';
import '../services/forgetting_curve_service.dart';

class ReviewLessonScreen extends StatefulWidget {
  final Lesson lesson;

  const ReviewLessonScreen({Key? key, required this.lesson}) : super(key: key);

  @override
  _ReviewLessonScreenState createState() => _ReviewLessonScreenState();
}

class _ReviewLessonScreenState extends State<ReviewLessonScreen> {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  bool _isLoading = false;
  bool _isReviewed = false;
  late Lesson _updatedLesson;
  String _motivationalMessage = '';

  @override
  void initState() {
    super.initState();
    _updatedLesson = widget.lesson;
    _motivationalMessage = ForgettingCurveService.getRandomMotivationalMessage();
  }

  Future<void> _markAsReviewed() async {
    setState(() {
      _isLoading = true;
    });

    // تحديث الدرس بعد المراجعة
    _updatedLesson = ForgettingCurveService.updateLessonAfterReview(widget.lesson);
    await _databaseHelper.updateLesson(_updatedLesson);

    setState(() {
      _isLoading = false;
      _isReviewed = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مراجعة الدرس'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (!_isReviewed) ...[
                    // بطاقة معلومات الدرس
                    Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.lesson.name,
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'المادة: ${widget.lesson.subject}',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.grey[700],
                              ),
                            ),
                            SizedBox(height: 16),
                            if (widget.lesson.note.isNotEmpty) ...[
                              Divider(),
                              SizedBox(height: 8),
                              Text(
                                'ملاحظات:',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                widget.lesson.note,
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 24),

                    // معلومات المراجعة
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.blue.shade200),
                      ),
                      child: Column(
                        children: [
                          Text(
                            'معلومات المراجعة',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 12),
                          _buildInfoRow(
                            'عدد المراجعات السابقة:',
                            '${widget.lesson.reviewCount}',
                          ),
                          _buildInfoRow(
                            'نقاط XP الحالية:',
                            '${widget.lesson.xpPoints}',
                          ),
                          _buildInfoRow(
                            'آخر مراجعة:',
                            widget.lesson.lastReviewed != null
                                ? _formatDate(widget.lesson.lastReviewed!)
                                : 'لم تتم المراجعة بعد',
                          ),
                          SizedBox(height: 16),
                          Text(
                            'هل أكملت مراجعة هذا الدرس؟',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24),

                    // زر المراجعة
                    ElevatedButton(
                      onPressed: _markAsReviewed,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'نعم، أكملت المراجعة',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ] else ...[
                    // شاشة النجاح بعد المراجعة
                    Container(
                      padding: EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.green.shade200),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 80,
                          ),
                          SizedBox(height: 16),
                          Text(
                            'تمت المراجعة بنجاح!',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Colors.green.shade800,
                            ),
                          ),
                          SizedBox(height: 24),
                          Text(
                            _motivationalMessage,
                            style: TextStyle(
                              fontSize: 18,
                              fontStyle: FontStyle.italic,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 24),
                          _buildRewardInfo(
                            'نقاط XP المكتسبة:',
                            '+${_updatedLesson.xpPoints - widget.lesson.xpPoints}',
                            Icons.star,
                            Colors.amber,
                          ),
                          SizedBox(height: 12),
                          _buildRewardInfo(
                            'المراجعة التالية:',
                            _formatDate(_updatedLesson.nextReviewDate!),
                            Icons.calendar_today,
                            Colors.blue,
                          ),
                          SizedBox(height: 24),
                          Text(
                            'كلما زاد عدد مرات المراجعة، زادت الفترة قبل الحاجة للمراجعة التالية وفقاً لمنحنى النسيان.',
                            style: TextStyle(fontSize: 14),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context, true);
                      },
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'العودة إلى القائمة الرئيسية',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRewardInfo(
      String label, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          SizedBox(width: 12),
          Text(
            label,
            style: TextStyle(fontSize: 16),
          ),
          Spacer(),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color.shade800,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now).inDays;

    if (difference == 0) {
      return 'اليوم';
    } else if (difference == 1) {
      return 'غداً';
    } else if (difference > 1 && difference < 7) {
      return 'بعد $difference أيام';
    } else {
      return '${date.year}/${date.month}/${date.day}';
    }
  }
}
