import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../services/database_helper.dart';

class AddLessonScreen extends StatefulWidget {
  const AddLessonScreen({Key? key}) : super(key: key);

  @override
  _AddLessonScreenState createState() => _AddLessonScreenState();
}

class _AddLessonScreenState extends State<AddLessonScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _subjectController = TextEditingController();
  final _noteController = TextEditingController();
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _subjectController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _saveLesson() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      final lesson = Lesson(
        name: _nameController.text.trim(),
        subject: _subjectController.text.trim(),
        note: _noteController.text.trim(),
        createdAt: DateTime.now(),
        reviewCount: 0,
        xpPoints: 0,
      );

      await _databaseHelper.insertLesson(lesson);

      setState(() {
        _isLoading = false;
      });

      Navigator.pop(context, true);
      
      // عرض رسالة نجاح
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم إضافة الدرس بنجاح!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('إضافة درس جديد'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // صورة توضيحية
                    Container(
                      height: 150,
                      margin: EdgeInsets.only(bottom: 24),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Icon(
                          Icons.book,
                          size: 80,
                          color: Colors.blue,
                        ),
                      ),
                    ),

                    // حقل اسم الدرس
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: 'اسم الدرس *',
                        hintText: 'مثال: الفصل الثالث - المعادلات التفاضلية',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        prefixIcon: Icon(Icons.title),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'يرجى إدخال اسم الدرس';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),

                    // حقل المادة
                    TextFormField(
                      controller: _subjectController,
                      decoration: InputDecoration(
                        labelText: 'المادة *',
                        hintText: 'مثال: رياضيات، فيزياء، لغة عربية',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        prefixIcon: Icon(Icons.category),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'يرجى إدخال اسم المادة';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),

                    // حقل الملاحظات
                    TextFormField(
                      controller: _noteController,
                      decoration: InputDecoration(
                        labelText: 'ملاحظات (اختياري)',
                        hintText: 'أضف أي ملاحظات إضافية هنا',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        prefixIcon: Icon(Icons.note),
                      ),
                      maxLines: 3,
                    ),
                    SizedBox(height: 24),

                    // معلومات توضيحية
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.amber.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.amber.shade200),
                      ),
                      child: Column(
                        children: [
                          Text(
                            'معلومات عن منحنى النسيان',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            'سيقوم التطبيق تلقائياً بتحديد مواعيد المراجعة المثالية لهذا الدرس بناءً على منحنى النسيان لهيرمان إبينغهاوس. كلما راجعت الدرس أكثر، كلما زادت الفترة قبل الحاجة للمراجعة التالية.',
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24),

                    // زر الحفظ
                    ElevatedButton(
                      onPressed: _saveLesson,
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'حفظ الدرس',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
