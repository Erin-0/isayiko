import 'package:flutter/material.dart';
import '../models/lesson.dart';
import 'dart:math';

class ForgettingCurveService {
  // منحنى النسيان - الفترات الزمنية للمراجعة بالأيام
  static const List<int> reviewIntervals = [1, 3, 7, 14, 30, 90, 180];

  // حساب موعد المراجعة التالي بناءً على عدد مرات المراجعة
  static DateTime calculateNextReviewDate(int reviewCount) {
    final now = DateTime.now();
    int daysToAdd = 1; // الافتراضي هو يوم واحد للمراجعة الأولى
    
    if (reviewCount < reviewIntervals.length) {
      daysToAdd = reviewIntervals[reviewCount];
    } else {
      // إذا تجاوز عدد المراجعات القائمة، نستخدم أطول فترة مع إضافة عشوائية
      daysToAdd = reviewIntervals.last + (reviewCount - reviewIntervals.length + 1) * 30;
    }
    
    return now.add(Duration(days: daysToAdd));
  }

  // حساب نقاط XP المكتسبة عند المراجعة
  static int calculateXpPoints(int currentXp, int reviewCount) {
    // كلما زاد عدد المراجعات، زادت النقاط المكتسبة
    int basePoints = 10;
    int bonusPoints = reviewCount * 5;
    return currentXp + basePoints + bonusPoints;
  }

  // تحديث الدرس بعد المراجعة
  static Lesson updateLessonAfterReview(Lesson lesson) {
    final now = DateTime.now();
    final newReviewCount = lesson.reviewCount + 1;
    final nextReviewDate = calculateNextReviewDate(newReviewCount);
    final newXpPoints = calculateXpPoints(lesson.xpPoints, newReviewCount);
    
    return Lesson(
      id: lesson.id,
      name: lesson.name,
      subject: lesson.subject,
      note: lesson.note,
      createdAt: lesson.createdAt,
      lastReviewed: now,
      reviewCount: newReviewCount,
      nextReviewDate: nextReviewDate,
      xpPoints: newXpPoints,
    );
  }

  // حساب نسبة التذكر الحالية بناءً على منحنى النسيان
  static double calculateMemoryRetention(Lesson lesson) {
    if (lesson.lastReviewed == null) {
      return 0.0;
    }

    final now = DateTime.now();
    final daysSinceLastReview = now.difference(lesson.lastReviewed!).inHours / 24;
    
    // معادلة منحنى النسيان لإبينغهاوس: R = e^(-t/S)
    // حيث R هي نسبة التذكر، t هو الوقت المنقضي، S هو قوة الذاكرة
    double memoryStrength = 1.0 + (lesson.reviewCount * 0.5); // تزداد قوة الذاكرة مع كل مراجعة
    double retention = exp(-daysSinceLastReview / memoryStrength);
    
    // تقييد النتيجة بين 0 و 1
    return retention.clamp(0.0, 1.0);
  }

  // إنشاء رسالة تحفيزية عشوائية
  static String getRandomMotivationalMessage() {
    final messages = [
      "أحسنت! استمر في المراجعة لتقوية ذاكرتك! 🧠✨",
      "رائع! أنت تتقدم بشكل ممتاز في رحلة التعلم! 💪📚",
      "تذكر، المراجعة المنتظمة هي مفتاح الذاكرة القوية! 🔑",
      "كل مراجعة تجعل المعلومات أكثر رسوخاً في ذاكرتك! 🌟",
      "أنت تتغلب على منحنى النسيان بنجاح! 📈",
      "استمر! أنت تبني ذاكرة قوية مع كل مراجعة! 🏗️",
      "عمل رائع! ذاكرتك تشكرك على هذه المراجعة! 🙏",
      "لا تنسَ أن تفخر بنفسك، أنت تستثمر في عقلك! 🎓",
    ];
    
    final random = Random();
    return messages[random.nextInt(messages.length)];
  }
}
