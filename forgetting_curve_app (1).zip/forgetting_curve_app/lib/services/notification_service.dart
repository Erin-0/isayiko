import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;
import '../models/lesson.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz_data.initializeTimeZones();

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
    );
  }

  Future<void> scheduleNotification(Lesson lesson) async {
    if (lesson.nextReviewDate == null) {
      return;
    }

    // إلغاء أي إشعارات سابقة لهذا الدرس
    await cancelNotification(lesson.id!);

    // جدولة إشعار جديد
    await flutterLocalNotificationsPlugin.zonedSchedule(
      lesson.id!,
      'حان وقت المراجعة! 🧠',
      'حان وقت مراجعة "${lesson.name}" لتثبيت المعلومات في ذاكرتك.',
      tz.TZDateTime.from(lesson.nextReviewDate!, tz.local),
      NotificationDetails(
        android: AndroidNotificationDetails(
          'forgetting_curve_channel',
          'إشعارات المراجعة',
          channelDescription: 'إشعارات لتذكيرك بمراجعة دروسك',
          importance: Importance.high,
          priority: Priority.high,
          color: Colors.blue,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelNotification(int id) async {
    await flutterLocalNotificationsPlugin.cancel(id);
  }

  Future<void> cancelAllNotifications() async {
    await flutterLocalNotificationsPlugin.cancelAll();
  }

  Future<void> showTestNotification() async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'forgetting_curve_channel',
      'إشعارات المراجعة',
      channelDescription: 'إشعارات لتذكيرك بمراجعة دروسك',
      importance: Importance.max,
      priority: Priority.high,
    );
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
      0,
      'اختبار الإشعارات',
      'هذا إشعار تجريبي للتأكد من عمل نظام الإشعارات',
      platformChannelSpecifics,
    );
  }
}
