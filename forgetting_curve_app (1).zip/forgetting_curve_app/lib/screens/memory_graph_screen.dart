import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/lesson.dart';
import '../services/forgetting_curve_service.dart';

class MemoryGraphScreen extends StatefulWidget {
  final List<Lesson> lessons;

  const MemoryGraphScreen({Key? key, required this.lessons}) : super(key: key);

  @override
  _MemoryGraphScreenState createState() => _MemoryGraphScreenState();
}

class _MemoryGraphScreenState extends State<MemoryGraphScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('رسم بياني للذاكرة'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // عنوان الصفحة
            Text(
              'تحليل منحنى النسيان',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'هذا الرسم البياني يوضح نسبة احتفاظك بالمعلومات في كل درس بناءً على منحنى النسيان لهيرمان إبينغهاوس.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 24),

            // رسم بياني للذاكرة
            if (widget.lessons.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(32.0),
                  child: Text(
                    'لا توجد دروس بعد. أضف دروساً جديدة لعرض الرسم البياني.',
                    style: TextStyle(fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                ),
              )
            else
              Column(
                children: [
                  Container(
                    height: 300,
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: _buildMemoryRetentionChart(),
                  ),
                  SizedBox(height: 24),
                  
                  // معلومات إضافية
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'إحصائيات الذاكرة',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 16),
                        _buildStatRow(
                          'متوسط نسبة الاحتفاظ:',
                          '${_calculateAverageRetention().toStringAsFixed(1)}%',
                          Icons.analytics,
                          Colors.blue,
                        ),
                        SizedBox(height: 8),
                        _buildStatRow(
                          'إجمالي المراجعات:',
                          '${_calculateTotalReviews()}',
                          Icons.repeat,
                          Colors.green,
                        ),
                        SizedBox(height: 8),
                        _buildStatRow(
                          'إجمالي نقاط XP:',
                          '${_calculateTotalXP()}',
                          Icons.star,
                          Colors.amber,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 24),
                  
                  // جدول الدروس مع نسب الاحتفاظ
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'تفاصيل الدروس',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 16),
                          ...widget.lessons
                              .map((lesson) => _buildLessonRetentionItem(lesson))
                              .toList(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMemoryRetentionChart() {
    // ترتيب الدروس حسب نسبة الاحتفاظ
    final sortedLessons = List<Lesson>.from(widget.lessons);
    sortedLessons.sort((a, b) {
      final retentionA = ForgettingCurveService.calculateMemoryRetention(a);
      final retentionB = ForgettingCurveService.calculateMemoryRetention(b);
      return retentionB.compareTo(retentionA);
    });

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: 1.0,
        barTouchData: BarTouchData(
          enabled: true,
          touchTooltipData: BarTouchTooltipData(
            tooltipBgColor: Colors.blueGrey.shade800,
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              final lesson = sortedLessons[groupIndex];
              final retention = ForgettingCurveService.calculateMemoryRetention(lesson);
              return BarTooltipItem(
                '${lesson.name}\n${(retention * 100).toStringAsFixed(1)}%',
                TextStyle(color: Colors.white),
              );
            },
          ),
        ),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                if (value >= sortedLessons.length || value < 0) {
                  return const SizedBox.shrink();
                }
                return Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    _shortenText(sortedLessons[value.toInt()].name, 10),
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontWeight: FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Text(
                    '${(value * 100).toInt()}%',
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontWeight: FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                );
              },
              reservedSize: 40,
            ),
          ),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        barGroups: List.generate(
          sortedLessons.length,
          (index) {
            final lesson = sortedLessons[index];
            final retention = ForgettingCurveService.calculateMemoryRetention(lesson);
            
            return BarChartGroupData(
              x: index,
              barRods: [
                BarChartRodData(
                  toY: retention,
                  color: _getColorForRetention(retention),
                  width: 20,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(6),
                    topRight: Radius.circular(6),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, String value, IconData icon, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        SizedBox(width: 8),
        Text(
          label,
          style: TextStyle(fontSize: 16),
        ),
        Spacer(),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }

  Widget _buildLessonRetentionItem(Lesson lesson) {
    final retention = ForgettingCurveService.calculateMemoryRetention(lesson);
    final retentionPercent = (retention * 100).toStringAsFixed(1);
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  lesson.name,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '$retentionPercent%',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: _getColorForRetention(retention),
                ),
              ),
            ],
          ),
          SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: retention,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(
                _getColorForRetention(retention),
              ),
              minHeight: 8,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'المراجعات: ${lesson.reviewCount} | المادة: ${lesson.subject}',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[600],
            ),
          ),
          Divider(),
        ],
      ),
    );
  }

  Color _getColorForRetention(double retention) {
    if (retention < 0.3) {
      return Colors.red;
    } else if (retention < 0.7) {
      return Colors.orange;
    } else {
      return Colors.green;
    }
  }

  String _shortenText(String text, int maxLength) {
    if (text.length <= maxLength) {
      return text;
    }
    return '${text.substring(0, maxLength)}...';
  }

  double _calculateAverageRetention() {
    if (widget.lessons.isEmpty) {
      return 0.0;
    }
    
    double totalRetention = 0.0;
    for (var lesson in widget.lessons) {
      totalRetention += ForgettingCurveService.calculateMemoryRetention(lesson);
    }
    
    return (totalRetention / widget.lessons.length) * 100;
  }

  int _calculateTotalReviews() {
    int total = 0;
    for (var lesson in widget.lessons) {
      total += lesson.reviewCount;
    }
    return total;
  }

  int _calculateTotalXP() {
    int total = 0;
    for (var lesson in widget.lessons) {
      total += lesson.xpPoints;
    }
    return total;
  }
}
